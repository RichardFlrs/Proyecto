from typing import Any
from time import sleep

class Empleado:
    __slops__  = ("empresa", "id_empleado", "ocupacion", "nombre", "fecha_nac")
    cantidad_emp = 0

    def __init__(self, id_empleado, ocupacion, nombre, fecha_nac):
        self.empresa = "\n----------------------------------\n\tMaya  Tecnology\n----------------------------------\n"
        self.id_empleado = str(id_empleado)+"-MTEC"
        self.ocupacion = ocupacion
        self.nombre = nombre
        self.fecha_nac = fecha_nac
        self.cantidad = Empleado.contador()

    def __str__(self):
        return f"ID: {self.id_empleado}\n\nOcupación: {self.ocupacion}\nNombre: {self.nombre}\nFecha de Nacimiento: {self.fecha_nac}\n"

    @classmethod
    def contador(cls):
        cls.cantidad_emp += 1
        return cls.cantidad_emp
    
    @staticmethod
    def by():
        print("\n       BY: Richard Flores")

    def cargar_datos(self):
        cont = 0

        while cont < 100:
            sleep(0.3)
            cont += 10
            print(f"Cargando Datos {cont}%")
        
        print()

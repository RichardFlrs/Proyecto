import Empleado

class DesignerUIX(Empleado.Empleado):
    def __init__(self, id_empleado, ocupacion, nombre, fecha_nac, dias_t, horas_ex):
        super().__init__(id_empleado, ocupacion, nombre, fecha_nac)
        self.pago_d = 95.99
        self.dias_t = dias_t
        self.horas_ex = horas_ex
        self.pago_h = 10.70

    def __str__(self):
        return super().__str__()+"Salario final: {} Bs".format(self.calculo_salario())
    
    def ocupacion():
        print("\nProgramador")

    def calculo_salario(self):
        return (self.pago_d * self.dias_t) + (self.horas_ex * self.pago_h)

    def designer():
        print("Diseñando...")
from Programador import Programador
from AdmBaseDatos import AdmBaseDatos
from DesignerUIX import DesignerUIX
from time import sleep

if __name__ == "__main__":
    programador = Programador(1, "Programador", "Ana Jimenez", "10-23-1995", 25, 5)
    admin_BD = AdmBaseDatos(2, "Administrador Base de Datos", "Juan Chavez", "01-15-1950", 28, 2)
    designer = DesignerUIX(3, "Designer UIX", "Roland Alvarez", "06-20-1750", 28, 2)

    band = True
    cont = 0
    
    for emp in (programador, admin_BD, designer):
        if band:
            emp.cargar_datos()
            emp.by()
            print(emp.empresa)
            band = False

        sleep(1)

        print(str(emp))

        if cont == emp.contador():
            print("\nCantidad de empleados:",emp.cantidad)

        cont += 1

    print("")
